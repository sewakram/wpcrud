<?php
/*
Plugin Name: Earning Report
Description:
Version: 1
Author: sewak
Author contact: +91968979541
*/
// function to create the DB / Options / Defaults					
function ss_options_install() {

    global $wpdb;

    $table_name = "earning";
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE $table_name (
			`id` int(10) NOT NULL,
			`ad_id` varchar(50) NOT NULL,
			`store` varchar(50) NOT NULL,
			`sale_amount` varchar(50) NOT NULL,
			`datetime` varchar(50) NOT NULL,
			`session_ip` varchar(50) NOT NULL,
			`conversion_status` varchar(50) NOT NULL,
			`approved_payout` varchar(50) NOT NULL,
			PRIMARY KEY (`id`)
          ) $charset_collate; ";

    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta($sql);
}

// run the install scripts upon plugin activation
register_activation_hook(__FILE__, 'ss_options_install');

//menu items
add_action('admin_menu','sinetiks_schools_modifymenu');
function sinetiks_schools_modifymenu() {
	
	//this is the main item for the menu
	add_menu_page('Earning Report', //page title
	'Earning Report', //menu title
	'manage_options', //capabilities
	'sinetiks_schools_list', //menu slug
	'sinetiks_schools_list' //function
	);
	
	//this is a submenu
	add_submenu_page('sinetiks_schools_list', //parent slug
	'Add New School', //page title
	'Add New', //menu title
	'manage_options', //capability
	'sinetiks_schools_create', //menu slug
	'sinetiks_schools_create'); //function
	
	//this submenu is HIDDEN, however, we need to add it anyways
	add_submenu_page(null, //parent slug
	'Update School', //page title
	'Update', //menu title
	'manage_options', //capability
	'sinetiks_schools_update', //menu slug
	'sinetiks_schools_update'); //function
}
define('ROOTDIR', plugin_dir_path(__FILE__));
require_once(ROOTDIR . 'schools-list.php');
require_once(ROOTDIR . 'schools-create.php');
require_once(ROOTDIR . 'schools-update.php');
