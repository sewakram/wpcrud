<?php

function sinetiks_schools_list() {
    ?>
    <link type="text/css" href="<?php echo WP_PLUGIN_URL; ?>/sinetiks-schools/style-admin.css" rel="stylesheet" />
    <div class="wrap">
        <h2>Earning Report</h2>
        <div class="tablenav top">
            <div class="alignleft actions">
                <a href="<?php echo admin_url('admin.php?page=sinetiks_schools_create'); ?>">Add New</a>
            </div>
            <br class="clear">
        </div>
        <?php
        global $wpdb;
        $table_name = "earning";

        $rows = $wpdb->get_results("SELECT * from $table_name");
        ?>
        <table class='wp-list-table widefat fixed striped posts'>
            <tr>
                <th class="manage-column ss-list-width">Ref ID</th>
                <th class="manage-column ss-list-width">Store</th>
                <th class="manage-column ss-list-width">Amount</th>
                <th class="manage-column ss-list-width">Time</th>
                <th class="manage-column ss-list-width">Payout</th>
                <th class="manage-column ss-list-width">IP</th>
                <th class="manage-column ss-list-width">Status</th>
                <th class="manage-column ss-list-width">Commission(%)</th>
                <!-- <th class="manage-column ss-list-width">Name</th> -->
                <th>&nbsp;</th>
            </tr>
            <?php foreach ($rows as $row) { ?>
                <tr>
                    <td class="manage-column ss-list-width"><?php echo $row->ad_id; ?></td>
                    <td class="manage-column ss-list-width"><?php echo $row->store; ?></td>
                    <td class="manage-column ss-list-width"><?php echo $row->sale_amount; ?></td>
                    <td class="manage-column ss-list-width"><?php echo $row->datetime; ?></td>
                    <td class="manage-column ss-list-width"><?php echo $row->approved_payout; ?></td>
                    <td class="manage-column ss-list-width"><?php echo $row->session_ip; ?></td>
                    <td class="manage-column ss-list-width"><?php echo $row->conversion_status; ?></td> 
                    <td class="manage-column ss-list-width"><?php echo $row->commission; ?></td>
                    
                    <td><a href="<?php echo admin_url('admin.php?page=sinetiks_schools_update&id=' . $row->id); ?>">Update</a></td>
                </tr>
            <?php } ?>
        </table>
    </div>
    <?php
}