
<?php

function eschool_class_create() {

    $class_name = $_POST["class_name"];
    $class_time = $_POST["class_time"];
    $duration = $_POST["duration"];
    $created_by=get_current_user_id();
    $classtimezone=get_option('timezone_string');
    $language="en";
    $recordclass=$_POST["recordclass"];
    //insert
    if (isset($_POST['insert'])) {
        global $wpdb;
        $table_name = $wpdb->prefix."eschool_wclasses";

        $wpdb->insert(
                $table_name, //table
                array('class_name' => $class_name, 'class_time' => $class_time,'duration' => $duration,'created_by' => $created_by,'classtimezone' => $classtimezone,'language' => $language,'recordclass' => $recordclass), //data
                array('%s', '%s', '%s') //data format			
        );
    
            $message.="Class created successfully";
        
    }
    ?>

        <link rel="stylesheet" type="text/css" media="screen" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css" />
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <script type="text/javascript" src="//code.jquery.com/jquery-2.1.1.min.js"></script>
        <script type="text/javascript" src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
    <link type="text/css" href="<?php echo WP_PLUGIN_URL; ?>/eschool/style-admin.css" rel="stylesheet" />
    <link type="text/css" href="<?php echo WP_PLUGIN_URL; ?>/eschool/bootstrap-datetimepicker.css" rel="stylesheet">
    <script type="text/javascript" src="<?php echo WP_PLUGIN_URL; ?>/eschool/moment-with-locales.js"></script>
    <script type="text/javascript" src="<?php echo WP_PLUGIN_URL; ?>/eschool/bootstrap-datetimepicker.js"></script>
    <div class="container">
        <h2>Create a class</h2>

        <?php if (isset($message)): ?><div class="updated"><p><?php echo $message; ?></p></div><?php endif; ?>
        
    <div class="row">
        <form method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>">
            
          <div class='form-group row'>
            <label class="col-sm-2 col-form-label" for="classname">Class title</label>
            <div class="col-sm-3">
            <input type="text" name="class_name" placeholder="Class Name" value="<?php echo $class_name; ?>" class="form-control" /></div>
         </div>


         <div class='form-group row'>
            <label class="col-sm-2 col-form-label" for="dandt">Date and time</label>
            <div class="col-sm-3">
            <div class='input-group date' id='datetimepicker1'>
                    <input type='text' placeholder="03/19/2018 12:36 PM" name="class_time" value="<?php echo $class_time; ?>" class="form-control" />
                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
            </div>
         </div>


         <div class='form-group row'>
            <label class="col-sm-2 col-form-label" for="duration">Class duration</label>
            <div class="col-sm-3">
            <input type="text" name="duration" value="<?php echo $duration; ?>" placeholder="30 minutes" class="form-control" />
            
            </div>
         </div>


          <div class='form-group row'>
            <label class="col-sm-2 col-form-label" for="duration">Class recording</label>
            <div class="col-sm-3">
            <input type="checkbox" class="filled-in form-check-input form-control" id="checkbox101" name="recordclass" value="Y">
            
            </div>
         </div>

         
         <div class='form-group row'>
            
            <div class="col-sm-1">
            
            <input type='submit' name="insert" value='Save' class='btn btn-success form-control'>
            </div>
         </div>

         </form>
        </div>
    </div>

<script type="text/javascript">
$(function () {
$('#datetimepicker1').datetimepicker();
});

</script>
    <?php
}
