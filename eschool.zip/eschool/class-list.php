<?php

function eschool_classes_list() {
    ?>
    <link type="text/css" href="<?php echo WP_PLUGIN_URL; ?>/sinetiks-schools/style-admin.css" rel="stylesheet" />
    <link type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.css" rel="stylesheet" />
    <link type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css" rel="stylesheet" />
    <script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>
    <div class="wrap">
        <ol class="breadcrumb">
  <li class="breadcrumb-item"><a href="#">Eschool</a></li>
  <li class="breadcrumb-item active">Classes</li>
</ol>
        <div class="tablenav top">
            <div class="alignleft actions">
                <a href="<?php echo admin_url('admin.php?page=eschool_class_create'); ?>">Add New</a>
            </div>
            <br class="clear">
        </div>
        <?php
        global $wpdb;
        $table_name = $wpdb->prefix . "eschool_wclasses";

        $rows = $wpdb->get_results("SELECT * from $table_name");
        ?>
        <table  id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>ID</th>
                <th>Class Name</th>
                <th>Shedule</th>
                <th>Duration</th>
                <th>Time Zone</th>
                <th>Language</th>
                <th>Recording</th>
                <th>Action</th>
                
            </tr>
            </thead>
            <tbody>
            <?php foreach ($rows as $row) { ?>
                <tr>
                    <td><?php echo $row->id; ?></td>
                    <td><?php echo $row->class_name; ?></td>
                    <td><?php echo $row->class_time; ?></td>
                    <td><?php echo $row->duration; ?></td>
                    <td><?php echo $row->classtimezone; ?></td>
                    <td><?php echo $row->language; ?></td>
                    <td><?php echo ($row->recordclass=='Y')?'Available':'Not available'; ?></td>
                    <td><a class="btn btn-danger" href="<?php echo admin_url('admin.php?page=eschool_class_update&id=' . $row->id); ?>">Update</a></td>
                </tr>
            <?php } ?>
            </tbody>
            <tfoot>
            <tr>
                <th>ID</th>
                <th>Class Name</th>
                <th>Shedule</th>
                <th>Duration</th>
                <th>Time Zone</th>
                <th>Language</th>
                <th>Recording</th>
                <th>Action</th>
            </tr>
            </tfoot>
        </table>
    </div>
    <script type="text/javascript">
$(document).ready(function() {
    $('#example').DataTable();
} );

</script>
    <?php
}