<?php
/*
Plugin Name: eSchools
Description:
Version: 1
Author: sewak
Author URI: http://webgile.com
*/
// function to create the DB / Options / Defaults	
/*
 * Create necessary tables while creating the plugin
 */ 
function eschool_table_create() {
	require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
	global $wpdb;
	$wiziq_courses = $wpdb->prefix."eschool_courses";
	$wiziq_wclasses = $wpdb->prefix."eschool_wclasses";
	$wiziq_enroluser = $wpdb->prefix."eschool_enroluser";
	$wiziq_contents = $wpdb->prefix."eschool_contents";
	$courses_creations = "CREATE TABLE $wiziq_courses (
		id int AUTO_INCREMENT PRIMARY KEY,
		created_by int NOT NULL,
		fullname varchar(255) NOT NULL,
		startdate datetime NULL DEFAULT NULL ,
		enddate datetime NULL DEFAULT NULL,
		description text NOT NULL
	);";
	$classes_creations = "CREATE TABLE $wiziq_wclasses (
		id int AUTO_INCREMENT PRIMARY KEY,
		created_by int NOT NULL,
		class_name varchar(100) NOT NULL,
		class_time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
		duration varchar(100) NOT NULL,
		courseid int NOT NULL,
		classtimezone varchar(100) NOT NULL,
		language varchar(100) NOT NULL,
		recordclass varchar(10) NOT NULL,
		attendee_limit int NOT NULL,
		response_class_id int NOT NULL,
		response_recording_url text NOT NULL,
		response_presenter_url text NOT NULL,
		status varchar(200) NOT NULL,
		master_id int(20) NOT NULL,
		attendence_report varchar(100) NOT NULL,
		get_detail tinyint NOT NULL,
		download_recording text NOT NULL,
		is_recurring varchar(10) NOT NULL
	);";
	$enroluser_creations = "CREATE TABLE $wiziq_enroluser (
		user_id int NOT NULL,
		course_id int NOT NULL,
		create_class tinyint NOT NULL,
		edit_class tinyint NOT NULL,
		delete_class tinyint NOT NULL,
		view_recording tinyint NOT NULL,
		download_recording tinyint NOT NULL,
		upload_content tinyint NOT NULL
	);";
	$content_creations = "CREATE TABLE $wiziq_contents (
		id int AUTO_INCREMENT PRIMARY KEY,
		status varchar(10) NOT NULL,
		created_by int NOT NULL,
		isfolder tinyint NOT NULL,
		name varchar(255) NOT NULL,
		parent int NOT NULL,
		content_id int NOT NULL,
		uploadingfile varchar(255) NOT NULL,
		folderpath varchar(100) NOT NULL
	);";
	if($wpdb->get_var("SHOW TABLES LIKE '$wiziq_courses'") != $wiziq_courses) {
		$wpdb->query($courses_creations);
	}
	if($wpdb->get_var("SHOW TABLES LIKE '$wiziq_wclasses'") != $wiziq_wclasses) {
		$wpdb->query($classes_creations);
	}
	if($wpdb->get_var("SHOW TABLES LIKE '$wiziq_enroluser'") != $wiziq_enroluser) {
		$wpdb->query($enroluser_creations);
	}
	if($wpdb->get_var("SHOW TABLES LIKE '$wiziq_contents'") != $wiziq_contents) {
		$wpdb->query($content_creations);
	}
	$content_qry = "insert into $wiziq_contents (created_by, isfolder, name, parent, content_id)
	values ( '0','1','My Content' ,'0', '0') ";
	$wpdb->query($content_qry) ;
}				
// function ss_options_install() {

//     global $wpdb;

//     $table_name = $wpdb->prefix . "eschool";
//     $charset_collate = $wpdb->get_charset_collate();
//     $sql = "CREATE TABLE $table_name (
//             `id` varchar(3) CHARACTER SET utf8 NOT NULL,
//             `name` varchar(50) CHARACTER SET utf8 NOT NULL,
//             PRIMARY KEY (`id`)
//           ) $charset_collate; ";

//     require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
//     dbDelta($sql);
// }

// run the install scripts upon plugin activation
register_activation_hook(__FILE__, 'eschool_table_create');

//menu items
add_action('admin_menu','sewak_eschools_modifymenu');
function sewak_eschools_modifymenu() {
	
	//this is the main item for the menu
	add_menu_page('Eschools', //page title
	'Eschools', //menu title
	'read', //capabilities
	'eschool_classes_list', //menu slug
	'eschool_classes_list' //function
	);
	
	//this is a submenu
	add_submenu_page('eschool_classes_list', //parent slug
	'Create a class', //page title
	'Shedule Class', //menu title
	'manage_options', //capability
	'eschool_class_create', //menu slug
	'eschool_class_create'); //function
	
	// //this submenu is HIDDEN, however, we need to add it anyways
	add_submenu_page(null, //parent slug
	'Update Class', //page title
	'Update', //menu title
	'manage_options', //capability
	'eschool_class_update', //menu slug
	'eschool_class_update'); //function
	add_submenu_page('eschool_classes_list', //parent slug
	'Classes', //page title
	'Classes', //menu title
	'read', //capability
	'eschool_classes_list', //menu slug
	'eschool_classes_list'); //function
}
define('ROOTDIR', plugin_dir_path(__FILE__));
require_once(ROOTDIR . 'class-list.php');
require_once(ROOTDIR . 'class-create.php');
require_once(ROOTDIR . 'schools-update.php');
