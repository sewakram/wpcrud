<?php

function eschool_class_update() {
    global $wpdb;
    $table_name = $wpdb->prefix . "eschool_wclasses";
    $id = $_GET["id"];
    $class_name = $_POST["class_name"];
    $class_time = $_POST["class_time"];
    $duration = $_POST["duration"];
    $recordclass=$_POST["recordclass"];
//update
    if (isset($_POST['update'])) {
        $wpdb->update(
                $table_name, //table
                array('class_name' => $class_name, 'class_time' => $class_time,'duration' => $duration,'recordclass' => $recordclass), //data
                array('ID' => $id), //where
                array('%s'), //data format
                array('%s') //where format
        );
    }
//delete
    else if (isset($_POST['delete'])) {
        $wpdb->query($wpdb->prepare("DELETE FROM $table_name WHERE id = %s", $id));
    } else {//selecting value to update	
        $schools = $wpdb->get_results($wpdb->prepare("SELECT * from $table_name where id=%s", $id));
        foreach ($schools as $s) {
            $name = $s->class_name;
        }
    }
    ?>
    
        <link type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.css" rel="stylesheet" />
        <link rel="stylesheet" type="text/css" media="screen" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css" />
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
        <link type="text/css" href="<?php echo WP_PLUGIN_URL; ?>/eschool/style-admin.css" rel="stylesheet" />
        <link type="text/css" href="<?php echo WP_PLUGIN_URL; ?>/eschool/bootstrap-datetimepicker.css" rel="stylesheet">

        <script type="text/javascript" src="//code.jquery.com/jquery-2.1.1.min.js"></script>
        <script type="text/javascript" src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="<?php echo WP_PLUGIN_URL; ?>/eschool/moment-with-locales.js"></script>
        <script type="text/javascript" src="<?php echo WP_PLUGIN_URL; ?>/eschool/bootstrap-datetimepicker.js"></script>
    <div class="wrap">
<ol class="breadcrumb">
  <li class="breadcrumb-item"><a href="#">Eschool</a></li>
  <li class="breadcrumb-item active">Update Class</li>
</ol>

        <?php if ($_POST['delete']) { ?>
            <div class="updated"><p>School deleted</p></div>
            <a href="<?php echo admin_url('admin.php?page=sinetiks_schools_list') ?>">&laquo; Back to schools list</a>

        <?php } else if ($_POST['update']) { ?>
            <div class="updated"><p>School updated</p></div>
            <a href="<?php echo admin_url('admin.php?page=sinetiks_schools_list') ?>">&laquo; Back to schools list</a>

        <?php } else { ?>
            <form method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>">
         
         <div class='form-group row'>
            <label class="col-sm-2 col-form-label" for="classname">Class title</label>
            <div class="col-sm-3">
            <input type="text" name="class_name" placeholder="Class Name" value="<?php if(!empty($s->class_name)) echo $s->class_name; ?>" class="form-control" /></div>
         </div>


         <div class='form-group row'>
            <label class="col-sm-2 col-form-label" for="dandt">Date and time</label>
            <div class="col-sm-3">
            <div class='input-group date' id='datetimepicker1'>
                    <input type='text' placeholder="03/19/2018 12:36 PM" name="class_time" value="<?php if(!empty($s->class_time)) echo $s->class_time; ?>" class="form-control" />
                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
            </div>
         </div>


         <div class='form-group row'>
            <label class="col-sm-2 col-form-label" for="duration">Class duration</label>
            <div class="col-sm-3">
            <input type="text" name="duration" value="<?php if(!empty($s->duration)) echo $s->duration; ?>" placeholder="30 minutes" class="form-control" />
            
            </div>
         </div>


          <div class='form-group row'>
            <label class="col-sm-2 col-form-label" for="duration">Class recording</label>
            <div class="col-sm-3">
            <input type="checkbox" class="filled-in form-check-input form-control" checked="<?php if($s->recordclass) echo "checked";?>" id="checkbox101" name="recordclass" value="Y">
            
            </div>
         </div>
                <input type='submit' name="update" value='Save' class='button'> &nbsp;&nbsp;
                <input type='submit' name="delete" value='Delete' class='button' onclick="return confirm('&iquest;Est&aacute;s seguro de borrar este elemento?')">
            </form>
        <?php } ?>

    </div>
    <script type="text/javascript">
$(function () {
$('#datetimepicker1').datetimepicker();
});

</script>
    <?php
}