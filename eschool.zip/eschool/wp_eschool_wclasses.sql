-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 31, 2018 at 12:56 PM
-- Server version: 5.7.21-0ubuntu0.16.04.1
-- PHP Version: 7.0.27-1+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wordpress`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_eschool_wclasses`
--

CREATE TABLE `wp_eschool_wclasses` (
  `id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `class_name` varchar(100) NOT NULL,
  `class_time` varchar(70) NOT NULL,
  `duration` varchar(100) NOT NULL,
  `classtimezone` varchar(100) NOT NULL,
  `language` varchar(100) NOT NULL,
  `recordclass` varchar(10) NOT NULL,
  `attendee_limit` int(11) NOT NULL,
  `response_class_id` int(11) NOT NULL,
  `response_recording_url` text NOT NULL,
  `response_presenter_url` text NOT NULL,
  `status` varchar(200) NOT NULL,
  `master_id` int(20) NOT NULL,
  `attendence_report` varchar(100) NOT NULL,
  `get_detail` tinyint(4) NOT NULL,
  `download_recording` text NOT NULL,
  `is_recurring` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wp_eschool_wclasses`
--

INSERT INTO `wp_eschool_wclasses` (`id`, `created_by`, `class_name`, `class_time`, `duration`, `classtimezone`, `language`, `recordclass`, `attendee_limit`, `response_class_id`, `response_recording_url`, `response_presenter_url`, `status`, `master_id`, `attendence_report`, `get_detail`, `download_recording`, `is_recurring`) VALUES
(5, 1, 'frghf', '03/19/2018 4:06 AM', '60', '', '', '', 0, 0, '', '', '', 0, '', 0, '', ''),
(6, 1, 'frghf', '03/19/2018 4:06 AM', '60', '', '', '', 0, 0, '', '', '', 0, '', 0, '', ''),
(7, 1, 'frghf', '03/29/2018 3:29 PM', '60', '', '', '', 0, 0, '', '', '', 0, '', 0, '', ''),
(8, 1, 'my class', '03/23/2018 3:34 PM', '60', 'Asia/Kolkata', '', '', 0, 0, '', '', '', 0, '', 0, '', ''),
(9, 1, 'my class', '03/16/2018 3:54 PM', '20', 'Asia/Kolkata', 'en', '', 0, 0, '', '', '', 0, '', 0, '', ''),
(10, 1, 'test', '03/21/2018 4:02 PM', '60', 'Asia/Kolkata', 'en', 'Y', 0, 0, '', '', '', 0, '', 0, '', ''),
(11, 1, 'my class', '03/31/2018 12:25 PM', '15', 'Asia/Kolkata', 'en', 'Y', 0, 0, '', '', '', 0, '', 0, '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_eschool_wclasses`
--
ALTER TABLE `wp_eschool_wclasses`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_eschool_wclasses`
--
ALTER TABLE `wp_eschool_wclasses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
